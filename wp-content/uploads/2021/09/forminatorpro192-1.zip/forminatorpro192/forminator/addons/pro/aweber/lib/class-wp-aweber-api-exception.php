<?php

/**
 * Class Forminator_Addon_Aweber_Wp_Api_Exception
 * Exception holder for Aweber wp api
 *
 * @since 1.0 Aweber Addon
 */
class Forminator_Addon_Aweber_Wp_Api_Exception extends Forminator_Addon_Aweber_Exception {
}
