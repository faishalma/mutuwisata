<?php

/**
 * Class Forminator_Addon_Trello_Exception
 * Not Required but encouraged
 *
 * @since 1.0 Trello Addon
 */
class Forminator_Addon_Trello_Exception extends Exception {

}
