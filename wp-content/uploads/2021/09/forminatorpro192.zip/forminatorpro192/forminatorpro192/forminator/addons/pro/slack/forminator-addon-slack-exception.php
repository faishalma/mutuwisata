<?php

/**
 * Class Forminator_Addon_Slack_Exception
 * Not Required but encouraged
 *
 * @since 1.0 Slack Addon
 */
class Forminator_Addon_Slack_Exception extends Exception {

}
