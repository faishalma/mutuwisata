<div class="integration-header">
	<h3 class="sui-box-title" id="dialogTitle2">
		<?php echo esc_html( sprintf( __( '%1$s Added', Forminator::DOMAIN ), 'Slack' ) ); ?>
	</h3>
	<p><?php esc_html_e( 'You can now go to your forms and assign them to this integration', Forminator::DOMAIN ); ?></p>
</div>
